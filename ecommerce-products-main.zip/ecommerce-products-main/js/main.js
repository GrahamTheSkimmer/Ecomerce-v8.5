import btnEvents from "./btnEvents.js";
import CartSection from './CartSection.js';

new CartSection('.cart__section' ,'.cart__container','.product__container')
btnEvents()
